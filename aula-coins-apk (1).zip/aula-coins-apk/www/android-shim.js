// Permite guardar/compartir archivos (copia JSON y plantillas Excel) dentro de la app Android.
(function () {
  const cap = window.Capacitor;
  if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return;

  const blobs = new Map();
  const origCreate = URL.createObjectURL;
  URL.createObjectURL = function (b) { const u = origCreate.call(URL, b); blobs.set(u, b); return u; };

  async function saveBlob(blob, name) {
    try {
      const { Filesystem, Share } = cap.Plugins;
      const data = await new Promise((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(String(r.result).split(',')[1]);
        r.onerror = rej;
        r.readAsDataURL(blob);
      });
      const f = await Filesystem.writeFile({ path: name, data, directory: 'CACHE' });
      await Share.share({ title: name, url: f.uri, dialogTitle: 'Guardar o compartir ' + name });
    } catch (e) {
      if (!String(e && e.message).toLowerCase().includes('cancel')) alert('No se pudo guardar el archivo.');
    }
  }

  const origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (this.download && blobs.has(this.href)) { saveBlob(blobs.get(this.href), this.download); return; }
    return origClick.call(this);
  };

  if (window.XLSX) {
    XLSX.writeFile = function (wb, name) {
      const out = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
      saveBlob(new Blob([out], { type: 'application/octet-stream' }), name);
    };
  }

  // Botón "atrás" de Android: cierra la ventana, vuelve a Inicio y, desde Inicio, sale de la app.
  const App = cap.Plugins && cap.Plugins.App;
  if (App && App.addListener) {
    App.addListener('backButton', () => {
      const m = document.getElementById('modal');
      if (m && m.classList.contains('open')) { closeModal(); return; }
      if (typeof currentSection !== 'undefined' && currentSection !== 'dashboard') { showSection('dashboard'); return; }
      App.exitApp();
    });
  }
})();
