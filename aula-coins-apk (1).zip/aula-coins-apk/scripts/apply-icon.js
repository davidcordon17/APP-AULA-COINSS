// Sustituye el icono por defecto de Capacitor por el de Aula Coins (se ejecuta tras "cap add android").
const fs = require('fs');
const res = 'android/app/src/main/res';
if (!fs.existsSync(res)) { console.log('No existe', res, '- se omite el icono'); process.exit(0); }
fs.cpSync('icon', res, { recursive: true });
const bg = res + '/values/ic_launcher_background.xml';
fs.mkdirSync(res + '/values', { recursive: true });
fs.writeFileSync(bg, '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#8B5CF6</color>\n</resources>\n');
console.log('Icono aplicado');
