// Copia SheetJS desde node_modules a www/ para que funcione sin Internet.
const fs = require('fs');
const src = require.resolve('xlsx/dist/xlsx.full.min.js');
fs.copyFileSync(src, 'www/xlsx.full.min.js');
console.log('SheetJS copiado a www/');
